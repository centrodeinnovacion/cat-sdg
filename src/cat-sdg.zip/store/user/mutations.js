export const SET_PROFILE = 'SET_PROFILE'
export const LOGOUT = 'LOGOUT'
