export default {
  id: '',
  tipo: 'pregunta',
  contenido: ''
}
