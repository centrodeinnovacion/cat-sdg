// // CAT-SDG con jgiraldocardozo@gmail.com
// export default {
//   apiKey: 'AIzaSyDr0-Mef6D1RZsD2NoBaPOwordhUW58MyU',
//   authDomain: 'contacts-app-dca62.firebaseapp.com',
//   databaseURL: 'https://contacts-app-dca62.firebaseio.com',
//   projectId: 'contacts-app-dca62',
//   storageBucket: 'contacts-app-dca62.appspot.com',
//   messagingSenderId: '715354469790'
// }

// CAT-SDG con jgiraldo@correo.unicordoba.edu.co
export default {
  apiKey: 'AIzaSyBrmU6VDuZf_q2kpQEx498C6om3LHS8zyY',
  authDomain: 'cat-sdg-aa433.firebaseapp.com',
  databaseURL: 'https://cat-sdg-aa433.firebaseio.com',
  projectId: 'cat-sdg-aa433',
  storageBucket: 'cat-sdg-aa433.appspot.com',
  messagingSenderId: '24774196594'
}
